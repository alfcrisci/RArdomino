#' clomax
#'
#' @description Find maximun clothing insulation require fot to feel thermal comfort state.
#' 
#' @param t  Temperature 
#' @param rh  Relative Humidity
#' @param wind Wind or air movement spped in m/s
#' @param tmrt Mean radiant Temperature
#' @param met Metabolism rate in w/m2
#' @param wkt External work in w/m2

#' @seealso \code{\link{pmv_iso_7730},\link{clomin}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples clo_max(22,50,0.1,22,70,0)
#' 
#' 
#' @export

clomax<-function(t,rh,wind,tmrt,met,wkt=0)

{    
    clo=5
    pmv_good=0.5;
    repeat { clo=clo-0.1 
            pmv <- pmv_iso_7730(t,rh,wind,tmrt,met,clo,wkt)
            if (pmv<pmv_good) break
           } 

  return(clo)
 
}




