#' 
#'
#' @description 
#' 
#' @param 
#' @param  
#' @param 
#' @param 
#' @param 
#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @import insol
#' @export

proj<-function( sunelev)
{
 if (sunelev < 0.0) {return(0.0)};
    
 return(0.308 * cos((3.141592653589793238462643/180.0) * (sunelev* (0.998- sunelev**2.0) / 50000.0)));
}