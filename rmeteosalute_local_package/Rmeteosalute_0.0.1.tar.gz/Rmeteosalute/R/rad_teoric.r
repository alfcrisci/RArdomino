#' rad_teoric
#'
#' @description Funtion to assess theoric solar irradiance.
#' 
#' @param timenow "POSIXct" or "POSIXt" 
#' @param  lat latitude in decimal degrees
#' @param lat longitude in decimal degrees
#' @param albedo environmental reflectivity

#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @examples rad_teoric(Sys.time(),lat=43,long=11,albedo=0)
#' 
#' 
#' @export

rad_teoric <- function(timenow,lat,long,albedo){
 rho=albedo
 res=sunposition(timenow,lat, long)
 elev=res$el
 timeday=as.POSIXlt(timenow, "GMT")
 nday=strptime(as.Date(timeday), "%Y-%m-%d")$yday+1
 # Solar constant
 SC = 1.361 # kW/m2
 # ET solar radition I0 kW/m2
 I0 <- SC*(1+0.034*cos((nday)*2*pi/365)) 
 # atmospheric effect
 A <- 1.160 + 0.075 * sin((nday-274)*2*pi/365)
 opt.depth <- 0.174 + 0.035 * sin((nday-100)*2*pi/365)
 air.mass <- 1/sin(elev*2*pi/360)
 # Direct
 IB <- I0*exp(-opt.depth*air.mass)
 # diffuse
 IDH <- IB*(0.095 + 0.04*sin((nday-100)*2*pi/365))
 ID <- IDH*(1+cos(pi-elev*2*pi/360))/2
 # reflected
 IBH <- IB*sin(elev*2*pi/360)
 IR <-  rho*(IBH+IDH)*(1+cos(pi-elev*2*pi/360))/2
 # total
 IT <- IB+ID+IR
 I <- cbind(IB,ID,IR,IT)
 return(list(I0=I0,A=A,opt.depth=opt.depth, air.mass=air.mass,I=I))
}