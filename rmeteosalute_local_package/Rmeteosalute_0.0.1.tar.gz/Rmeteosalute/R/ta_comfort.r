#' 
#'
#' @description 
#' 
#' @param rh
#' @param clo 
#' @param wind
#' @param M
#' @param H
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples ta_comfort(rh=50,clo=1,wind=0.1,M=70,H=2)
#' 
#' 
#' @export

ta_comfort<-function(rh,clo,wind,M,H)
{   out=.C("ta_comfort",i_rh=as.double(rh),i_clo=as.double(clo),i_wind=as.double(wind),i_M=as.double(M),i_H=as.double(H),r_ta_comfort=as.double(-999))
    return(out$r_ta_comfort)
 
}
