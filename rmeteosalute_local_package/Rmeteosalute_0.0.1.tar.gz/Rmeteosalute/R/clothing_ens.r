#' 
#'
#' @description 
#' 
#' @param t Temperature (*C)
#' @param rh  Relative Humidity (%)

#' @seealso \code{\link{pmv_iso_7730}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords Indoor Climate, ISO 7730
#' @examples
#' 
#' 
#' @export

clothing_ens<-function(t,rh)
{   tapp_indoor=indoor_tapp(t,rh)

    frasi_8=c("Copriamoci bene non sara il caso di scherzare! Look and feel!",
              "Che dire qui e\' come una ghiacciaia quindi....")

    frasi_7=c("Freddo e freddo e cosi riusciamo a stare bene.",
              "Un caldo consiglio.....")

    frasi_6=c("Ancora si sene il bisogno di esser coperti",
              "Ambiente termico non proprio neutrale.")

    frasi_5=c("Vestirsi bene non e\' poi cosi difficile vista la situazione.",
              "E' facile sapere come vestirsi.")

    frasi_4=c("Un suggerimento per stare comodi.",
              "Non � difficile stare bene se vestiti cosi.")

    frasi_3=c("Cosi con il comfort abbiamo fatto pace cosi vestiti.",
              "Quasi quasi ecco cosi ci siamo.")

    frasi_2=c(paste("Con una temperatura apparente di ",sprintf("%.1f",tapp_indoor),"gradi..."),
              "E' facile sentire caldo come indicano i dati rilevati.")

    frasi_1=c("Il caldo e\' pi� che una percezione quindi per stare bene.. ",
              "Non � una gara di intimo ma ...")

    r=sample(1:length(frasi_1),1,replace=T)

    ########################################################################################

    res_clo=list( classe=NA,frase="Non riesco a definirla",nomeimg="")

    if ( tapp_indoor <= -3 )                       {res_clo$classe=8;res_clo$frase=frasi_8[r];res_clo$nomeimg="clo_8.jpg"};
    if ( tapp_indoor  < 3 && tapp_indoor >= -2 )   {res_clo$classe=7;res_clo$frase=frasi_7[r];res_clo$nomeimg="clo_7.jpg"};
    if ( tapp_indoor  < 7 && tapp_indoor >= 3 )    {res_clo$classe=6;res_clo$frase=frasi_6[r];res_clo$nomeimg="clo_6.jpg"};
    if ( tapp_indoor  < 11 && tapp_indoor >= 7 )   {res_clo$classe=5;res_clo$frase=frasi_5[r];res_clo$nomeimg="clo_5.jpg"};
    if ( tapp_indoor  < 17 && tapp_indoor >= 11)   {res_clo$classe=4;res_clo$frase=frasi_4[r];res_clo$nomeimg="clo_4.jpg"};
    if ( tapp_indoor  < 22 && tapp_indoor >= 17 )  {res_clo$classe=3;res_clo$frase=frasi_3[r];res_clo$nomeimg="clo_3.jpg"};
    if ( tapp_indoor  < 28 && tapp_indoor >= 22 )  {res_clo$classe=2;res_clo$frase=frasi_2[r];res_clo$nomeimg="clo_2.jpg"};
    if ( tapp_indoor >= 28 )                       {res_clo$classe=1;res_clo$frase=frasi_1[r];res_clo$nomeimg="clo_1.jpg"}


    return(res_clo)
 
}