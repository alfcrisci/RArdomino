#' 
#'
#' @description 
#' 
#' @param 
#' @param  
#' @param 
#' @param 
#' @param 
#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @export

utci_class_10<-function(t,rh,wind,tmrt)
{   if ( t < -50.0 || t > 50.0 ) return(NA);
    if ( tmrt < t-30.0 || tmrt > t+70.0 ) return(NA);
    if ( rh <= 0.0 || rh >= 100.0 ) return(NA);
    out=.C("utci_class_10",i_t=as.double(t),i_rh=as.double(rh),i_wind=as.double(wind),i_tmrt=as.double(tmrt),r_utci_class_10=as.double(-999))
    return(out$r_utci_class_10)
 
}