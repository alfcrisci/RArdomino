#' 
#'
#' @description 
#' 
#' @param 
#' @param  
#' @param 
#' @param 
#' @param 
#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @import insol
#' @export
e_sat<-function(t)
{  if ( t < -50.0 || t > 50.0 ) return(NA);
    out=.C("e_sat",i_ta=as.double(t),r_es=as.double(-999))
    return(out$r_es)
 
}