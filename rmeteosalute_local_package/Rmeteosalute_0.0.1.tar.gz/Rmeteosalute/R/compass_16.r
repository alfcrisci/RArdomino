#' 
#'
#' @description 
#' 
#' @param 
#' @param  
#' @param 
#' @param 
#' @param 
#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @export

compass_16<-function(direction)

{ dir = c( "N", "NNE", "NE", "ENE", "E", "ESE", "SE",
                                   "SSE", "S", "SSW", "SW", "WSW", "W", "WNW",
                                   "NW", "NNW");
  dirint=(((direction+11.25)/22.5));							   
  return(dir[as.integer(dirint %%16)+1])
}
