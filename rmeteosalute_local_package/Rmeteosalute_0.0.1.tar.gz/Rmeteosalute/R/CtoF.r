#' 
#'
#' @description Convert temperature in Farenheith
#' 
#' @param t Temperature in Celsius
 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @export

CtoF<-function(t)
{
  return (t * 1.8+ 32.0);
}