#' 
#'
#' @description 
#' 
#' @param 
#' @param  
#' @param 
#' @param 
#' @param 
#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @import insol
#' @export

outdoor_shade<-function(t,rh,wind)
{   out=.C("steadman_outdoor_shade",i_t=as.double(t),i_rh=as.double(rh),i_wind=as.double(wind),r_steadshade=as.double(-999))
    return(out$r_steadshade)
 
}