#' 
#'
#' @description 
#' 
#' @param 
#' @param  
#' @param 
#' @param 
#' @param 
#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @export

wdirection<-function(u,v)
{   out=.C("wdirection",i_u=as.double(u),i_v=as.double(i_v),r_wdir=as.double(-999))  
    return(out$r_wdir)
 
} 