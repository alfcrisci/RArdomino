#' 
#'
#' @description 
#' 
#' @param 
#' @param  
#' @param 
#' @param 
#' @param 
#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @import insol
#' @export

hi_wind<-function(t,wind)
{   out=.C("hi_wind",i_t=as.double(t),i_w=as.double(wind),r_hi_wind=as.double(-999))
    return(out$r_hi_wind)
 
}