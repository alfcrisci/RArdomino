#' 
#'
#' @description 
#' 
#' @param 
#' @param  
#' @param 
#' @param 
#' @param 
#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @export

t_apparent_aus<-function(t,rh,wind)
{   out=.C("t_apparent_aus",i_t=as.double(t),i_rh=as.double(rh),i_wind=as.double(wind),t_apparent_aus=as.double(-999))
    return(out$t_apparent_aus)
 
}