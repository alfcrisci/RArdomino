#' 
#'
#' @description 
#' 
#' @param t
#' @param rh 
#' @param wind
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @export

sto_shade_class<-function(t,rh,wind)
{   out=.C("sto_shade_class",i_t=as.double(t),i_rh=as.double(rh),i_wind=as.double(wind),r_sto_shade_class=as.double(-999))
    return(out$r_sto_shade_class)
 
} 