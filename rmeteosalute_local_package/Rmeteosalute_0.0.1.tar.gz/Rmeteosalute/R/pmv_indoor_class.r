#' 
#'
#' @description 
#' 
#' @param t Temperature (*C)
#' @param rh  Relative Humidity (%)
#' @param wind Wind or Air movement speed (m/s)
#' @param tmrt Mean Radiant Temperature (*C)
#' @param met Metabolism Rate (W/m2)
#' @param wkt External work . Default value =0 (W/m2)
#' @param iclo Clothing insulation (clo)
#' @notes Valid for indoor environment
#' @seealso \code{\link{pmv_iso_7730}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords Indoor Climate, ISO 7730
#' @examples
#' 
#' 
#' @export

pmv_indoor_class<-function(t,rh,wind,tmrt,met,wkt=0,iclo)
{   res_pmvc=pmv_iso_7730(t,rh,wind,tmrt,met,wkt,iclo)
    
    classe=c("Freddo","Fresco","Comfort","Tiepido","Caldo");

    frasi_1=c("Sensazione di disagio da freddo decisa!",
              "E' facile sentire freddo come indicano i dati rilevati")

    frasi_2=c("Sensazione di disagio di fresco.",
              "E' facile sentire fresco come indicano i dati rilevati")

    frasi_3=c("Sensazione di assenza disagio quindi comfortevole.",
              "Ambiente termico neutrale")

    frasi_4=c("Sensazione di tiepore!",
              "E' facile sentire un certo tiepore come indicano i dati rilevati")

    frasi_5=c("Sensazione di disagio da caldo.",
              "E' facile sentire caldo come indicano i dati rilevati")



    ########################################################################################
    r=sample(1:length(frasi_1),1,replace=T);
    res_pmv=list( class_num=NA,classe="Indefinita",frase="Non riesco a definirla")

    if ( res_pmvc <= -1.5 ) {res_pmv$class_num=1;res_pmv$classe=classe[1];res_pmv$frase=frasi_1[r];}
    if ( res_pmvc  < -0.5 && res_pmvc > -1.5 ) {res_pmv$class_num=2;res_pmv$classe=classe[2];res_pmv$frase=frasi_2[r];}
    if ( res_pmvc  < 0.5 && res_pmvc > 0.5 ) {res_pmv$class_num=3;res_pmv$classe=classe[3];res_pmv$frase=frasi_3[r];}
    if ( res_pmvc  < 1.5 && res_pmvc > 0.5 ) {res_pmv$class_num=4;res_pmv$classe=classe[4];res_pmv$frase=frasi_4[r];}
    if ( res_pmvc >= 1.5 ) {res_pmv$class_num=5;res_pmv$classe=classe[5];res_pmv$frase=frasi_5[r];}


    return(res_pmv)
 
}