#' 
#'
#' @description Assess Mean radiant temperature
#' 
#' @param t 
#' @param rh 
#' @param rdiffuse
#' @param sunelev
#' @param albedo

#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @export

temprad<-function(t,rh,rshort,rdiffuse,sunelev,albedo)
{   out=.C("temprad",i_t=as.double(t),i_rh=as.double(rh),i_rshort=as.double(rshort),i_rdiffuse=as.double(rdiffuse),i_sunelev=as.double(sunelev),i_albedo=as.double(albedo),r_temprad=as.double(-999))
    return(out$r_temprad)
 
}