#' 
#'
#' @description Convert 
#' 
#' @param tF
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples FtoC(80) # 26.66668
#' 
#' 
#' @export

FtoC<-function(tF)
{
  return (tF * 0.555556- 17.7778);
}
