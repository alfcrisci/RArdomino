#' 
#'
#' @description 
#' 
#' @param t 
#' @param rh 
#' @param wind
#' @param tmrt
#' @param met
#' @param clo
#' @param wkt

#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples  pmv_iso_7730(22,50,0.1,22,70,1,0)  
#' 
#' 
#' @import insol
#' @export

pmv_iso_7730<-function(t,rh,wind,tmrt,met,clo,wkt) { 
 
  # clo=1; met=1.2;wind=20; t=22;mean.rad.temp=22;saturation=50;external.work=wkt;
  # Adapted from CIBSE Guide A, 1.A1.2, p. 51

  saturated.vapour.pressure <- exp(16.6536-4030.183/(t+235)) # kPa
  vapour.pressure <- saturated.vapour.pressure*10*rh # Pa
  iclo <- 0.155*clo
  fcl <- ifelse(iclo<0.078,
                          1 + 1.29*iclo,
                          1.05 + 0.645*iclo);

  convective.heat <- 12.1 * sqrt(wind); 
  t.kel <- t + 273
  tmrt <- t.kel 
  # compute clothing surface temperature by iteration
  tcl <- t.kel +(35.5 - t)/(3.5*(6.45*iclo + 0.1))
  p1 <- iclo*fcl
  p2 <- p1*3.96
  p3 <- p1*100 # Error in CIBSE Guide
  p4 <- p1*t.kel
  p5 <- 308.7 - 0.028*(met - wkt) + p2*(tmrt/100)^4
  xn <- tcl/100
  xf <- xn
  eps <- 0.000015
  hc <- 0
  repeat {
    xf <- (xf + xn)/2
    heat.transf.nat <- 2.38*abs(100*xf-t.kel)^0.25
    hc <- pmax(convective.heat, heat.transf.nat)
    xn <- (p5 + p4*hc - p2*xf^4)/(100 + p3*hc)
    if (all(abs(xn-xf)<eps)) break
  }
  tcl <- 100*xn - 273
  # end iteration
  heat.loss.skin <- 3.05*0.001*(5733-6.99*(met - wkt)-vapour.pressure) # CIBSE Guide has an error here
  heat.loss.sweat <- pmax(0.42*((met - wkt) - 58.15), 0)
  heat.loss.respiration <- 1.7*0.00001*met*(5867 - vapour.pressure)
  heat.loss.dry <- 0.0014*met*(34 - t)
  heat.loss.rad <- 3.96*fcl*(xn^4 - (tmrt/100)^4)
  heat.loss.conv <- fcl*hc*(tcl - t)
  tsens <- 0.303*exp(-0.036*met) + 0.028
  pmv=tsens*((met - wkt) - heat.loss.skin - heat.loss.sweat
              - heat.loss.respiration - heat.loss.dry
              - heat.loss.rad - heat.loss.conv)
  return(pmv)
			  
}