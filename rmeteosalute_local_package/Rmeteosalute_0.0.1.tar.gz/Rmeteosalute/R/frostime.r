#' 
#'
#' @description frostime 
#' 
#' @param  t
#' @param  wind 

#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @import insol
#' @export

frostime<-function(t,wind)
{   out=.C("frostime",i_t=as.double(t),i_wind=as.double(wind),r_frostime=as.double(-999.9))
    return(out$r_frostime)
 
} 