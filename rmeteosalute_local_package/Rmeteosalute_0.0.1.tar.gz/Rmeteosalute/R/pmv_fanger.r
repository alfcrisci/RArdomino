#' 
#'
#' @description 
#' 
#' @param t
#' @param rh 
#' @param wind
#' @param tmrt
#' @param met
#' @param clo
#' @note 
#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' pmv_hoppe(25,49,0.2,27,88,1)
#' 
#' @export

pmv_fanger<-function(t,rh,wind,tmrt,met,clo)
{   out=.C("pmv_iso",i_t=as.double(t),i_rh=as.double(rh),i_wind=as.double(wind),i_mtrad=as.double(tmrt),i_met=as.double(met),i_iclo=as.double(clo),r_pmv=as.double(-999))
    return(out$r_pmv)
 
}