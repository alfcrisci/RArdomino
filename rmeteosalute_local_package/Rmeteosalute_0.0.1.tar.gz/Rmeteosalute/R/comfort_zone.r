#' comfort_zone
#'
#' @description define the  appartenence in a winter/summer comfort zone.
#' 
#' @param t Temperature in Celsius degree �C
#' @param rh Relative Humidity in %  

#' 
#' @seealso \code{\link{XXX}}
#' @references 
#' Istituto di Biometeorologia Firenze Italy
#' Centro Interdipartimentale di Bioloclimatologia University of Florence
#' @author  Alfonso crisci \email{a.crisci@@ibimet.cnr.it} and Marco Morabito \email{m.morabito@@unifi.it} 
#' @keywords 
#' @examples
#' 
#' 
#' @import sp
#' @export

comfort_zone<-function(t,rh,season="estate"){
require(sp)

summer_cz_ashrae=data.frame(t_cz=c(22.5,26,27,23.5),rh_cz=c(79.5,57.3,19.8,24.4))
winter_cz_ashrae=data.frame(t_cz=c(19.5,23.5,24.5,20.5),rh_cz=c(86.5,58.3,23,29.3))
winter_cz_iso=data.frame(t_cz=c(20,20,24,24),rh_cz=c(30,70,30,70))
summer_cz_iso=data.frame(t_cz=c(23,23,26,26),rh_cz=c(30,70,30,70))

res=list(iso_ita="No",iso_eng="No",iso_num=0,ashrae_ita="No",ashrae_eng="No",ashrae_num=0,
         msg_iso="Non sei in una comfort zone, mi dispiace!",msg_as="Non sei in una comfort zone, mi dispiace!")

if  ( season != "estate") {
if (point.in.polygon(t,rh,winter_cz_ashrae$t_cz, winter_cz_ashrae$rh_cz, mode.checked=FALSE) >0) {res$ashrae_ita="si";
                                                                                                  res$washrae_eng="yes";
														res$washrae_num=1;
														res$msg_as="Siamo in comfort zone valida per la stagione invernale!"
														}

if (point.in.polygon(t,rh,winter_cz_iso$t_cz, winter_cz_iso$rh_cz, mode.checked=FALSE) >0) {res$iso_ita="si";
                                                                                            res$iso_eng="yes";
													 res$iso_num=1;
													 msg_iso="Siamo in comfort zone  valida per la stagione invernale!";	
										                                                   }    

		               }

else {						
if (point.in.polygon(t,rh,summer_cz_ashrae$t_cz, summer_cz_ashrae$rh_cz, mode.checked=FALSE) >0) {res$ashrae_ita="si";
                                                                                                  res$washrae_eng="yes";
														res$washrae_num=1;
														res$msg_as="Siamo in comfort zone valida per la stagione estiva!"
														}

if (point.in.polygon(t,rh,summer_cz_iso$t_cz, summer_cz_iso$rh_cz, mode.checked=FALSE) >0) {res$iso_ita="si";
                                                                                            res$iso_eng="yes";
													 res$iso_num=1;
													 msg_iso="Siamo in comfort zone  valida per la stagione estiva!";
													}    

   }
return(res);
}